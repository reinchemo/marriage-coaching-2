<?php require_once('../config.php') ?>
<!DOCTYPE html>
<html lang="en" class="" style="height: 100%;">
<?php require_once('inc/header.php') ?>
<body class="hold-transition login-page" style="background: url('https://images-pw.pixieset.com/elementfield/0J1RroO/Indian-wedding-photographer-in-kenya-2-923f18e0-2500.jpg') no-repeat center center fixed; background-size: cover; min-height: 100vh;">
  <script>
    start_loader()
  </script>

<!-- Login Box Container -->
<div class="login-box">
  <div class="card card-outline card-primary shadow">
    <div class="card-header text-center">
      <a href="./" class="h1 text-primary"><b>Login</b></a>
    </div>
    <div class="card-body bg-white rounded">
      <p class="login-box-msg">Sign in to start your session</p>

      <form id="login-frm" action="" method="post">
        <div class="input-group mb-3">
          <input type="text" class="form-control" name="username" placeholder="Username" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control" name="password" placeholder="Password" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <a href="<?php echo base_url.'customer' ?>" class="text-primary">Go to Website</a>
          </div>
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
          </div>
        </div>
      </form>

    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

<script>
  $(document).ready(function(){
    end_loader();
  })
</script>
</body>
</html>
