<h1>Welcome to <?php echo $_settings->info('name') ?></h1>



<!-- Full Page Background Section with Paragraph -->
<div style="
  background: url('https://capitalchoicecounselling.com/wp-content/uploads/2013/10/Married-Couple-Fingers-Crossed.jpg') no-repeat center center fixed;
  background-size: cover;
  height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px;
">
  <div style="
    background: rgba(255, 255, 255, 0.9);
    padding: 40px;
    border-radius: 10px;
    max-width: 900px;
    text-align: center;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
  ">
    <h2 class="text-primary mb-3">Empowering Healthy Relationships</h2>
    <p style="font-size: 18px; color: #333;">
      Welcome to a platform built for love, growth, and connection. Our Marriage and Relationships Coaching System provides expert advice, practical tools, and a safe virtual space where couples and individuals can thrive emotionally.
    </p>
    <p style="font-size: 18px; color: #333;">
      Whether you're just starting out or looking to rekindle a long-term bond, our system supports your journey with personalized guidance and transformative coaching experiences—all online, all at your pace.
    </p>
  </div>
</div>

